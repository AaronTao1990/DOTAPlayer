0.先安装Sketch 然后点一下；
1.将sketch_v3复制到中 /Users/xiongyongxin/Library/Application Support；
2.双击运行sketch_v3
4.Result: 1显示破解完成